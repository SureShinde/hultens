/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
define([
    'jquery',
    'priceUtils',
    'priceBox',
    'jquery/ui'
], function ($, utils) {
    'use strict';

    $.widget('mageworx.optionInventory', {
        options: {
            optionConfig: {}
        },

        firstRun: function firstRun(optionConfig, productConfig, base, self)
        {
            var form = base.element,
                options = $('.product-custom-option', form);

            self._applyOptionNodeFix(options, base);
        },

        update: function update(option, optionConfig, productConfig, base)
        {
            return;
        },

        _applyOptionNodeFix: function applyOptionNodeFix(options, base)
        {
            var self = this,
                config = base.options,
                optionConfig = config.optionConfig;

            $.ajax({
                    url: 'mageworx_optioninventory/stockmessage/update',
                    data: {'opConfig':JSON.stringify(optionConfig)},
                    type: 'post',
                    dataType: 'json'
                })
                .done(function (response) {
                    if (response) {
                        self._updateOptionsData(options, response.result);
                    } else {
                        self._updateOptionsData(options, optionConfig);
                    }
                }).fail(
                function (response) {
                    self._updateOptionsData(options, optionConfig);
                }
            );
        },

        _updateOptionsData: function(options, opConfig)
        {
            this._updateSelectOptions(options.filter('select'), opConfig);
            this._updateInputOptions(options.filter('input'), opConfig);
        },

        _updateSelectOptions: function(options, opConfig)
        {
            options.each(function (index, element) {
                var $element = $(element),
                    optionId = utils.findOptionId($element);

                if ($element.hasClass('datetime-picker')) {
                    return true;
                }

                var optionConfig = opConfig[optionId];

                $element.find('option').each(function (idx, option) {
                    var $option,
                        optionValue,
                        stockMessage;

                    $option = $(option);
                    optionValue = $option.val();

                    if (!optionValue && optionValue !== 0) {
                        return;
                    }

                    stockMessage = optionConfig[optionValue] && optionConfig[optionValue].stockMessage;

                    if (optionConfig[optionValue].stockMessage !== undefined) {
                        $option.text($option.text() + ' ' + stockMessage);
                    }
                });
            });
        },

        _updateInputOptions: function(options, opConfig)
        {
            options.each(function (index, element) {
                var $element = $(element),
                    optionId = utils.findOptionId($element),
                    optionValue = $element.val();

                if ($element.hasClass('datetime-picker')) {
                    return true;
                }

                var optionConfig = opConfig[optionId],
                    valueText = optionConfig[optionValue] && optionConfig[optionValue].name,
                    stockMessage = optionConfig[optionValue] && optionConfig[optionValue].stockMessage;

                if (stockMessage !== undefined) {
                    $element.next('label').text(valueText + ' ' + stockMessage);
                }
            });
        },
    });

    return $.mageworx.optionInventory;

});