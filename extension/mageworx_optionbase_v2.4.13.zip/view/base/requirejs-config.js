/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

var config = {
    map: {
        '*': {
            optionBase: 'MageWorx_OptionBase/js/catalog/product/base',
        }
    }
};
